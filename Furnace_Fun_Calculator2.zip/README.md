# Furnace_Fun_Calculator

This build is currently in Beta.

This build is dynamically linked, so keep all files together

Features that don't work:
French language search
German language search
German question display
French question display